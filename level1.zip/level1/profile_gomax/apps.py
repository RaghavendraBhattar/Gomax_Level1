from django.apps import AppConfig


class ProfileGomaxConfig(AppConfig):
    name = 'profile_gomax'
