from django.contrib import admin
from .models import ObjectTracking,Address,ContactDetails,Person,organisation
# Register your models here.

#admin.site.register(ObjectTracking)
admin.site.register(Address)
admin.site.register(ContactDetails)
admin.site.register(Person)
admin.site.register(organisation)

