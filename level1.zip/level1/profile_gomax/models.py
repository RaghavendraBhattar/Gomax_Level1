from django.db import models
from django.utils import timezone
from multiselectfield import MultiSelectField
# Create your models here.

class ObjectTracking(models.Model):
    createdDate = models.DateTimeField(auto_now_add=True, null=True)
    updatedDate = models.DateTimeField(auto_now_add=True)
    created_by=models.CharField(max_length=250, null=True)
    updated_by = models.CharField(max_length=250, null=True)

    class Meta():
        abstract=True






class Address(ObjectTracking):
    address1=models.CharField(max_length=250, null=True)
    address2 = models.CharField(max_length=250, null=True)
    city=models.CharField(max_length=250, null=True)
    state=models.CharField(max_length=250, null=True)
    country=models.CharField(max_length=250, null=True)
    pincode=models.IntegerField()

    def __str__(self):
        return self.city


class ContactDetails(ObjectTracking):
    contactchoices=(('mobile','mobile'),('landline','landline'),('whatsapp','whatsapp'),
                   ('facebook_id','facebook_id'),('twitter','twitter'),('email','email'))
    ChildProcessError=models.CharField(max_length=250,choices=contactchoices)
    detail=models.IntegerField()



class Person(ObjectTracking):
    name=models.CharField(max_length=100,null=True)
    addresses=models.ForeignKey(Address,null=True, on_delete=models.SET_NULL)
    Contact_Details=models.ManyToManyField(ContactDetails)


class organisation(ObjectTracking):
    name=models.CharField(max_length=250, null=True)
    Org_address=models.CharField(max_length=250, null=True)
    ContactPerson=models.ForeignKey(Person, null=True, on_delete=models.SET_NULL)
    ContactDetail=models.ManyToManyField(ContactDetails)






