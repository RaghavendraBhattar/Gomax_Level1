from django.apps import AppConfig


class AuthGomaxConfig(AppConfig):
    name = 'auth_gomax'
